# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mytest.spec.ts >> SauceDemo нэвтрэх функц >> 1. Амжилттай нэвтрэх
- Location: tests/mytest.spec.ts:22:7

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator:  getByText('Products')
Expected: "WRONG TEXT"
Received: "Products"
Timeout:  5000ms

Call log:
  - Expect "toHaveText" getByText('Products') with timeout 5000ms
  - waiting for getByText('Products')
    14 × locator resolved to <span class="title" data-test="title">Products</span>
       - unexpected value "Products"

```

```yaml
- text: Products
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | 
  3  | // Багшийн өгсөн жишээ код
  4  | // test('амжилттай нэвтэрлээ', async ({ page }) => {
  5  | // await page.goto('https://www.saucedemo.com');
  6  | // await page.getByPlaceholder('Username').fill('standard_user');
  7  | // await page.getByPlaceholder('Password').fill('secret_sauce');
  8  | // await page.getByRole('button', { name: 'Login' }).click();
  9  | // await expect(page.getByText('Products')).toBeVisible();
  10 | // });
  11 | 
  12 | 
  13 | 
  14 | // Тестлэх сайт: SauceDemo
  15 | const BASE_URL = 'https://www.saucedemo.com';
  16 | const VALID_USER = 'standard_user';
  17 | const VALID_PASS = 'secret_sauce';
  18 | const INVALID_PASS = 'wrong_password';
  19 | 
  20 | test.describe('SauceDemo нэвтрэх функц', () => {
  21 | 
  22 |   test('1. Амжилттай нэвтрэх', async ({ page }) => {
  23 |     await page.goto(BASE_URL);
  24 | 
  25 |     //"getByPlaceholder" нь "XPath"-аас илүү 
  26 |     // тодорхой болон хэрэглэгчдэд ээлтэй, ойлгомжтой тул 
  27 |     // энгийн тестэнд тохиромжтой.
  28 |     await page.getByPlaceholder('Username').fill(VALID_USER);
  29 |     await page.getByPlaceholder('Password').fill(VALID_PASS);
  30 |     await page.getByRole('button', { name: 'Login' }).click();
  31 | 
  32 |     // Нэвтэрсний дараа Products хуудас руу шилжсэн эсэхийг шалгах
  33 |     // await expect(page.getByText('Products')).toBeVisible();
  34 |     // Энэ хэсэг нь бол албаар тестэнд алдаа гаргахын тулд хийсэн хэсэг юм. Тиймээс энэ хэсгийг коммент хийж болно.
> 35 |     await expect(page.getByText('Products')).toHaveText('WRONG TEXT');
     |                                              ^ Error: expect(locator).toHaveText(expected) failed
  36 |     await expect(page).toHaveURL(/inventory\.html/);
  37 |   });
  38 | 
  39 |   test('2. Амжилтгүй нэвтрэх (буруу нууц үг)', async ({ page }) => {
  40 |     await page.goto(BASE_URL);
  41 | 
  42 |     await page.getByPlaceholder('Username').fill(VALID_USER);
  43 |     await page.getByPlaceholder('Password').fill(INVALID_PASS);
  44 |     await page.getByRole('button', { name: 'Login' }).click();
  45 | 
  46 |     // Алдаа гарч байгааг шалгах
  47 |     await expect(page.getByText('Username and password do not match')).toBeVisible();
  48 |     // Нэвтрэх хуудсанд гацсан үгүйг шалгах
  49 |     await expect(page).toHaveURL(BASE_URL + '/');
  50 |   });
  51 | 
  52 |   test('3. Нэвтэрсний дараах үйлдэл — бараа сагслах', async ({ page }) => {
  53 |     await page.goto(BASE_URL);
  54 |     await page.getByPlaceholder('Username').fill(VALID_USER);
  55 |     await page.getByPlaceholder('Password').fill(VALID_PASS);
  56 |     await page.getByRole('button', { name: 'Login' }).click();
  57 |     await expect(page.getByText('Products')).toBeVisible();
  58 | 
  59 |     // Нэгдүгээр барааг сагслах, товч дарах
  60 |     await page.getByRole('button', { name: 'Add to cart' }).first().click();
  61 | 
  62 |     // Сагсны тоолуур "1" болсныг шалгах
  63 |     await expect(page.locator('.shopping_cart_badge')).toHaveText('1');
  64 | 
  65 |     // Сагсийг шалгах
  66 |     await page.locator('.shopping_cart_link').click();
  67 |     await expect(page.locator('.cart_item')).toHaveCount(1);
  68 | 
  69 |     // logout
  70 |     await page.locator('#react-burger-menu-btn').click();
  71 |     await page.getByRole('link', { name: 'Logout' }).click();
  72 |     await expect(page.getByPlaceholder('Username')).toBeVisible();
  73 |   });
  74 | 
  75 | });
  76 | 
```